//
//  BlueView.h
//  BUTTON——NO
//
//  Created by 张厚琪 on 2018/4/17.
//  Copyright © 2018年 DDG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlueView : UIView
@property (nonatomic,strong) UIButton *redButton;
@end
