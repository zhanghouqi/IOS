//
//  ViewController.m
//  BUTTON——NO
//
//  Created by 侠客1 on 2018/4/17.
//  Copyright © 2018年 DDG. All rights reserved.
//

#import "ViewController.h"
#import "BlueView.h"

@interface ViewController ()
@property (nonatomic,strong) BlueView *blueView;

@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.blueView.backgroundColor = [UIColor blueColor];
    
    
    [self.blueView.redButton addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
}
-(void)btnClicked:(UIButton *)sender{
    NSLog(@"Button was clicked.");
}
-(BlueView *)blueView{
    if (_blueView) {
        return _blueView;
    }
    self.blueView = [BlueView new];
    [self.view addSubview:self.blueView];
    self.blueView.frame = CGRectMake(0, 60, self.view.frame.size.width, 60);
    
    return self.blueView;
}


@end
